import React, { Component } from 'react';
import RegistrationFrom from '../RegistrationForm'; 
import './App.css';

class App extends Component {
  render() {
    return (
      <main className="App">
        <RegistrationFrom />
      </main>
    );
  }
}

export default App;
