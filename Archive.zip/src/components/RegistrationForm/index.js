import RegistrationForm from './RegistrationForm'; 

export default RegistrationForm; 